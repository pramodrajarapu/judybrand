package com.Brand.Brand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrandApplicationTests {

	@Test
	void contextLoads() {
	}

}
